# Implementing CNN in PyTorch with Custom Dataset and Transfer Learning
Dataset Link - https://www.kaggle.com/c/dogs-vs-cats/data

Link to medium article: https://medium.com/@ajinkya.pahinkar98/implementing-cnn-in-pytorch-with-custom-dataset-and-transfer-learning-1864daac14cc
